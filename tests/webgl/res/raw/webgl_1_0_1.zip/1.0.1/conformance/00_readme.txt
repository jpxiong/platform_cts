This file "00_test_list.txt" lists which files the test harness should run.

If you add new tests you can update it with

on windows

   dir /b *.html >00_test_list.txt

on OSX / Linux

   ls -1 *.html >00_test_list.txt


